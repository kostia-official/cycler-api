import supertest from 'supertest';
import faker from 'faker';
import app from '../src/app';

const request = supertest(app);

describe('error handler', () => {
  it('should respond with BadRequest for validation errors', async () => {
    const cycle = {
      name: faker.random.word(),
      periodicity: 'daily',
      fieldsTemplates: [{}]
    };
    await request
      .post('/cycles')
      .send(cycle)
      .expect(400);
  });
});
