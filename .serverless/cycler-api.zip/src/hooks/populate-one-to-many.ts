import { HookContext } from '@feathersjs/feathers';
import _ from 'lodash';

interface IPopulateCreatedParams {
  mainTable: string;
  relatedTable: string;
  foreignKey: string;
}

export const populateOneToMany = ({
  mainTable,
  relatedTable,
  foreignKey
}: IPopulateCreatedParams) => async (context: HookContext) => {
  // const mongoose = context.app.get('mongooseClient');
  //
  // const relatedRecords = await Promise.all(
  //   _.map(context.result, (mainRecord) => {
  //     return mongoose.model(relatedTable).find({ [foreignKey]: context.result._id });
  //   })
  // );
  //
  // context.result = result;

  return context;
};
