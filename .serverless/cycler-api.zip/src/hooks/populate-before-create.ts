import { HookContext } from '@feathersjs/feathers';
import _ from 'lodash';

interface IPopulateCreatedParams {
  fieldInMain: string;
  relatedTable: string;
}

export const populateBeforeCreate = ({
  relatedTable,
  fieldInMain
}: IPopulateCreatedParams) => async (context: HookContext) => {
  const mongoose = context.app.get('mongooseClient');

  const relatedDataResult = await mongoose.model(relatedTable).create(context.data[fieldInMain]);
  context.data = { ...context.data, [fieldInMain]: _.map(relatedDataResult, '_id') };

  return context;
};
