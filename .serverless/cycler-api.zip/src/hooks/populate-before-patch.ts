import { HookContext } from '@feathersjs/feathers';
import _ from 'lodash';
import { ObjectId } from 'bson';

interface IPopulateCreatedParams {
  fieldInMain: string;
  relatedTable: string;
}

export const populateBeforePatch = ({
  relatedTable,
  fieldInMain
}: IPopulateCreatedParams) => async (context: HookContext) => {
  const model = context.app.get('mongooseClient').model(relatedTable);

  const relatedDataResult = await Promise.all(
    _.map(context.data[fieldInMain], (record) => {
      return record._id
        ? model.findOneAndUpdate({ _id: record._id }, record)
        : model.create(record);
    })
  );

  context.data = { ...context.data, [fieldInMain]: _.map(relatedDataResult, '_id') };

  return context;
};
