import { populateManyToMany } from '../../hooks/populate-many-to-many';
import { populateBeforeCreate } from '../../hooks/populate-before-create';
import { populateBeforePatch } from '../../hooks/populate-before-patch';

export default {
  before: {
    all: [],
    find: [],
    get: [],
    create: [
      populateBeforeCreate({
        fieldInMain: 'fieldsTemplates',
        relatedTable: 'fieldsTemplates'
      })
    ],
    update: [
      populateBeforePatch({
        fieldInMain: 'fieldsTemplates',
        relatedTable: 'fieldsTemplates'
      })
    ],
    patch: [
      populateBeforePatch({
        fieldInMain: 'fieldsTemplates',
        relatedTable: 'fieldsTemplates'
      })
    ],
    remove: []
  },

  after: {
    all: [],
    find: [],
    get: [],
    create: [populateManyToMany({ mainTable: 'cycles', relatedTable: 'fieldsTemplates' })],
    update: [populateManyToMany({ mainTable: 'cycles', relatedTable: 'fieldsTemplates' })],
    patch: [populateManyToMany({ mainTable: 'cycles', relatedTable: 'fieldsTemplates' })],
    remove: []
  },

  error: {
    all: [],
    find: [],
    get: [],
    create: [],
    update: [],
    patch: [],
    remove: []
  }
};
