import { Application } from '../declarations';
import { acl } from '../acl';
import { checkJwt } from './checkJwt';
import _ from 'lodash';

export default function(app: Application) {
  _.forEach(acl, ({ route, methods, allow }) => {
    app.use(route, (req, res, next) => {
      if (!methods.includes(req.method)) return next();

      if (allow.isAuthenticated) {
        return checkJwt(req, res, next);
      }

      return next();
    });
  });

  app.use(function(err: any, req: any, res: any, next: any) {
    if (err.name === 'UnauthorizedError') {
      res.status(401).send('invalid token...');
    }
  });
}
